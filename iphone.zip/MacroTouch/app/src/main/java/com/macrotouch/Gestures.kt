package com.macrotouch

import kotlin.math.cos
import kotlin.math.sin

/**
 * Built-in gestures expressed as the same Stroke/Pt data the recorder produces, so they go through
 * exactly the same player (and red touch circles) as recorded macros. Times are in ms.
 */
object GestureLib {
    private fun one(x: Float, y: Float, t0: Long, t1: Long) = Stroke(listOf(Pt(x, y, t0), Pt(x, y, t1)))

    fun tap(x: Float, y: Float) = listOf(one(x, y, 0, 50))
    fun doubleTap(x: Float, y: Float) = listOf(one(x, y, 0, 50), one(x, y, 170, 220))
    fun longPress(x: Float, y: Float, ms: Long = 1000) = listOf(one(x, y, 0, ms))

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 350) =
        listOf(Stroke(listOf(Pt(x1, y1, 0), Pt(x2, y2, ms))))

    /** Press and hold at (x1,y1), then drag to (x2,y2) without lifting. */
    fun holdDrag(x1: Float, y1: Float, x2: Float, y2: Float, hold: Long = 600, drag: Long = 700) =
        listOf(Stroke(listOf(Pt(x1, y1, 0), Pt(x1, y1, hold), Pt(x2, y2, hold + drag))))

    /**
     * Two fingers on opposite sides of (cx,cy). Radius goes r1 -> r2 (pinch), and the pair rotates by
     * [deg] degrees (clockwise on screen) over [ms]. deg = 0 is a pure pinch, r1 == r2 a pure rotation.
     */
    fun twoFinger(cx: Float, cy: Float, r1: Float, r2: Float, deg: Float, ms: Long = 700): List<Stroke> {
        val steps = if (deg == 0f) 1 else 24
        val a = ArrayList<Pt>(); val b = ArrayList<Pt>()
        for (i in 0..steps) {
            val f = i / steps.toFloat()
            val r = r1 + (r2 - r1) * f
            val th = Math.toRadians((deg * f).toDouble())
            val dx = (r * cos(th)).toFloat(); val dy = (r * sin(th)).toFloat()
            val t = (ms * f).toLong()
            a.add(Pt(cx + dx, cy + dy, t)); b.add(Pt(cx - dx, cy - dy, t))
        }
        return listOf(Stroke(a), Stroke(b))
    }
}
