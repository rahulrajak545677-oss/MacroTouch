package com.macrotouch

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Point
import android.os.Handler
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE

/**
 * Overlay position manager for the red touch buttons.
 *
 * It is deliberately separate from the gesture engine (Player):
 *  - Every position here is a VIEW position (where a red ring is drawn). It lives only in this class
 *    and in its own "bp_*" / "ic_*" preference keys.
 *  - Gesture coordinates live only in Macro.strokes. This class only READS them once, to pick a default
 *    place for a button, and never writes them. Dragging or collapsing buttons cannot change a macro.
 *  - Player never reads anything from here, so playing a macro does not move any button or the icon.
 *
 * Expanded: one red button per saved macro (at that macro's first touch point by default). Tap = play it.
 * Collapsed: all buttons fold into ONE red ring that stays where it is and lets touches pass through.
 */
class ButtonLayer(
    private val ctx: Context,
    private val wm: WindowManager,
    private val h: Handler,
    private val screen: () -> Point,
    private val newParams: (Int, Int, Int) -> WindowManager.LayoutParams,
    private val onTap: (String) -> Unit
) {
    class RingView(c: Context) : View(c) {
        private val d = c.resources.displayMetrics.density
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2D3A.toInt(); style = Paint.Style.STROKE; strokeWidth = 5 * d }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FF2D3A }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2D3A.toInt() }
        override fun onDraw(c: Canvas) {
            val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f - 3 * d
            c.drawCircle(cx, cy, r, fill); c.drawCircle(cx, cy, r, ring); c.drawCircle(cx, cy, r * 0.16f, dot)
        }
    }

    private class Btn(val name: String, var x: Float, var y: Float, val view: RingView, val p: WindowManager.LayoutParams)

    private val d = ctx.resources.displayMetrics.density
    private val size = (60 * d).toInt()
    private val btns = mutableListOf<Btn>()
    private var icon: RingView? = null
    private var animator: ValueAnimator? = null
    private var passThrough = false
    var collapsed = Store.getBool(ctx, "collapsed", false); private set
    val hasButtons get() = btns.isNotEmpty()

    private fun land(sz: Point) = if (sz.x > sz.y) "l" else "p"
    private fun key(prefix: String, sz: Point, name: String = "") = "${prefix}_${land(sz)}_$name"

    private fun readXY(k: String): Pair<Float, Float>? {
        val v = Store.getStr(ctx, k, "")
        val a = v.split(","); if (a.size != 2) return null
        val x = a[0].toFloatOrNull(); val y = a[1].toFloatOrNull()
        return if (x != null && y != null) x to y else null
    }

    private fun place(p: WindowManager.LayoutParams, x: Float, y: Float) {
        p.gravity = Gravity.TOP or Gravity.START
        p.x = (x - size / 2f).toInt(); p.y = (y - size / 2f).toInt()
    }

    private fun safeRemove(v: View?) { try { if (v != null) wm.removeView(v) } catch (_: Exception) {} }
    private fun safeUpdate(v: View, p: WindowManager.LayoutParams) { try { wm.updateViewLayout(v, p) } catch (_: Exception) {} }

    /** Rebuild from the saved macros. Does not change any macro or any saved button position. */
    fun refresh() {
        clear()
        val sz = screen()
        for (m in Store.load(ctx)) {
            val f = m.strokes.firstOrNull()?.pts?.firstOrNull() ?: continue
            if (m.sw > 0 && m.sh > 0 && (m.sw > m.sh) != (sz.x > sz.y)) continue   // other orientation: no button
            val sx = if (m.sw > 0) sz.x / m.sw.toFloat() else 1f
            val sy = if (m.sh > 0) sz.y / m.sh.toFloat() else 1f
            val pos = readXY(key("bp", sz, m.name)) ?: (f.x * sx to f.y * sy)
            val v = RingView(ctx)
            val p = newParams(size, size, 0); place(p, pos.first, pos.second)
            val b = Btn(m.name, pos.first, pos.second, v, p)
            attachTouch(b)
            btns.add(b)
        }
        if (collapsed && btns.isNotEmpty()) showIcon() else { collapsed = collapsed && btns.isNotEmpty(); btns.forEach { add(it) } }
    }

    private fun add(b: Btn) {
        b.p.flags = if (passThrough) b.p.flags or FLAG_NOT_TOUCHABLE else b.p.flags and FLAG_NOT_TOUCHABLE.inv()
        try { wm.addView(b.view, b.p) } catch (_: Exception) {}
    }

    private fun attachTouch(b: Btn) {
        var dx = 0f; var dy = 0f; var ox = 0f; var oy = 0f; var drag = false
        b.view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ox = b.x; oy = b.y; drag = false }
                MotionEvent.ACTION_MOVE -> {
                    if (!drag && Math.hypot((e.rawX - dx).toDouble(), (e.rawY - dy).toDouble()) > 10 * d) drag = true
                    if (drag) { b.x = ox + e.rawX - dx; b.y = oy + e.rawY - dy; place(b.p, b.x, b.y); safeUpdate(b.view, b.p) }
                }
                MotionEvent.ACTION_UP -> {
                    if (drag) Store.putStr(ctx, key("bp", screen(), b.name), "${b.x},${b.y}")   // view position only
                    else onTap(b.name)
                }
            }
            true
        }
    }

    /** While a macro runs the rings must not catch the injected touches that land on them. */
    fun setPassThrough(on: Boolean) {
        passThrough = on
        if (collapsed) return
        for (b in btns) {
            b.p.flags = if (on) b.p.flags or FLAG_NOT_TOUCHABLE else b.p.flags and FLAG_NOT_TOUCHABLE.inv()
            safeUpdate(b.view, b.p)
        }
    }

    fun toggle() { if (collapsed) expand() else collapse() }

    fun collapse() {
        if (collapsed || btns.isEmpty()) return
        val sz = screen()
        val first = btns[0]
        val ix = first.x; val iy = first.y            // the icon stays exactly here until expanded
        collapsed = true
        Store.putBool(ctx, "collapsed", true)
        Store.putStr(ctx, key("ic", sz), "$ix,$iy")
        animateTo(ix, iy, false) { btns.forEach { safeRemove(it.view) }; showIcon() }
    }

    fun expand() {
        if (!collapsed) return
        collapsed = false
        Store.putBool(ctx, "collapsed", false)
        val sz = screen()
        val ic = readXY(key("ic", sz)) ?: (btns.firstOrNull()?.let { it.x to it.y } ?: (0f to 0f))
        safeRemove(icon); icon = null
        for (b in btns) { place(b.p, ic.first, ic.second); add(b) }
        animateTo(ic.first, ic.second, true) {}
    }

    /** Animate window positions only; Btn.x / Btn.y (the remembered original spots) are never touched. */
    private fun animateTo(tx: Float, ty: Float, outward: Boolean, done: () -> Unit) {
        animator?.cancel()
        val from = btns.map { it.x to it.y }
        val a = ValueAnimator.ofFloat(0f, 1f).apply { duration = 200 }
        a.addUpdateListener { va ->
            val f = va.animatedValue as Float
            val g = if (outward) 1f - f else f      // outward: icon spot -> original; inward: original -> icon spot
            btns.forEachIndexed { i, b ->
                val (ox, oy) = from[i]
                place(b.p, ox + (tx - ox) * g, oy + (ty - oy) * g)
                safeUpdate(b.view, b.p)
            }
        }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: android.animation.Animator) {
                if (outward) btns.forEach { place(it.p, it.x, it.y); safeUpdate(it.view, it.p) }
                done()
            }
        })
        animator = a; a.start()
    }

    private fun showIcon() {
        val sz = screen()
        val pos = readXY(key("ic", sz)) ?: (btns[0].x to btns[0].y)
        val v = RingView(ctx)
        val p = newParams(size, size, FLAG_NOT_TOUCHABLE)      // touches pass through to the app below
        place(p, pos.first, pos.second)
        try { wm.addView(v, p) } catch (_: Exception) {}
        icon = v
    }

    private fun clear() {
        animator?.cancel(); animator = null
        btns.forEach { safeRemove(it.view) }; btns.clear()
        safeRemove(icon); icon = null
    }

    fun hide() { clear() }
}
