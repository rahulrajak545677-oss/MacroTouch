# Macro Touch (Android)

AssistiveTouch-style floating button + gesture recorder/player for Android.

## Build the APK (no PC needed)
1. Create a GitHub repo, upload this whole folder (keep `.github/workflows/build.yml`).
2. Repo → Actions → "Build APK" → Run workflow.
3. Download artifact `MacroTouch-APK`, unzip, install `app-debug.apk`.

(Or open the folder in Android Studio → Run.)

## First run
1. Open Macro Touch → switch **AssistiveTouch** on → enable the accessibility service "Macro Touch".
   Android 13+: Settings → Apps → Macro Touch → ⋮ → *Allow restricted settings*, then enable it.
2. A floating button appears. Tap it → **Custom → +** (or "Create New Gesture…" in the app).
3. Tap/swipe (multi-finger OK) → **Save** → type a name.
4. Go to your game/app → tap button → Custom → your gesture. Tap the button again to stop. Repeat count/delay: app → Playback.
