package com.macrotouch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import org.json.JSONArray
import org.json.JSONObject

data class Pt(val x: Float, val y: Float, val t: Long)

data class Stroke(val pts: List<Pt>) {
    val start get() = pts.first().t
    val end get() = pts.last().t
    /** finger position at time t (ms since macro start), null if not touching */
    fun posAt(t: Long): Pair<Float, Float>? {
        if (t < start || t > end + 120) return null
        if (t >= end) return pts.last().x to pts.last().y
        for (i in 1 until pts.size) {
            val a = pts[i - 1]; val b = pts[i]
            if (t <= b.t) {
                val f = if (b.t == a.t) 1f else (t - a.t).toFloat() / (b.t - a.t)
                return (a.x + (b.x - a.x) * f) to (a.y + (b.y - a.y) * f)
            }
        }
        return null
    }
}

data class Macro(val name: String, val strokes: List<Stroke>) {
    val duration get() = strokes.maxOfOrNull { it.end } ?: 0L
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("macrotouch", Context.MODE_PRIVATE)
    fun getInt(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun getStr(c: Context, k: String, d: String) = sp(c).getString(k, d) ?: d
    fun putStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun getBool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun load(c: Context): MutableList<Macro> {
        val out = mutableListOf<Macro>()
        try {
            val arr = JSONArray(sp(c).getString("macros", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ss = o.getJSONArray("s")
                val strokes = (0 until ss.length()).map { k ->
                    val pa = ss.getJSONArray(k)
                    Stroke((0 until pa.length()).map { j ->
                        val p = pa.getJSONArray(j)
                        Pt(p.getDouble(0).toFloat(), p.getDouble(1).toFloat(), p.getLong(2))
                    })
                }
                out.add(Macro(o.getString("n"), strokes))
            }
        } catch (_: Exception) {}
        return out
    }

    fun save(c: Context, list: List<Macro>) {
        val arr = JSONArray()
        list.forEach { m ->
            val o = JSONObject().put("n", m.name)
            val ss = JSONArray()
            m.strokes.forEach { s ->
                val pa = JSONArray()
                s.pts.forEach { p -> pa.put(JSONArray().put(p.x.toDouble()).put(p.y.toDouble()).put(p.t)) }
                ss.put(pa)
            }
            arr.put(o.put("s", ss))
        }
        sp(c).edit().putString("macros", arr.toString()).apply()
    }
}

/** Red ringed touch circles with a short trail, like iOS shows during playback. */
fun drawTouches(c: Canvas, strokes: List<Stroke>, t: Long, ox: Float, oy: Float, r: Float, ring: Paint, fill: Paint) {
    for (s in strokes) for (k in 0..8) {
        val p = s.posAt(t - k * 35L) ?: continue
        val a = 255 - k * 18
        fill.alpha = (a * 0.4f).toInt(); ring.alpha = a
        val x = p.first - ox; val y = p.second - oy
        c.drawCircle(x, y, r, fill)
        c.drawCircle(x, y, r, ring)
        if (k == 0) {
            fill.alpha = 255
            c.drawCircle(x - r * 0.3f, y, r * 0.12f, fill)
            c.drawCircle(x + r * 0.3f, y, r * 0.12f, fill)
        }
    }
}
