package com.macrotouch

import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** "New Gesture" screen: Cancel / title / Save on top, Play + timeline + Stop at the bottom. */
class RecorderView(
    ctx: Context,
    private val defaultName: String,
    private val onCancel: () -> Unit,
    private val onSave: (String, List<Stroke>) -> Unit
) : FrameLayout(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val done = mutableListOf<Stroke>()
    private val live = HashMap<Int, MutableList<Pt>>()
    private var t0 = 0L
    private var locked = false
    private var previewing = false
    private var previewT0 = 0L
    private var naming = false
    private var panel: LinearLayout? = null
    private val loc = IntArray(2)

    private val BLUE = 0xFF0A84FF.toInt()
    private val GREY = 0xFF8E8E93.toInt()

    private val trail = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCC0A84FF.toInt(); style = Paint.Style.STROKE; strokeWidth = 30 * d
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2D3A.toInt(); style = Paint.Style.STROKE; strokeWidth = 5 * d }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2D3A.toInt(); style = Paint.Style.FILL }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3A3A3C.toInt(); strokeWidth = 4 * d; strokeCap = Paint.Cap.ROUND }
    private val prog = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = BLUE; strokeWidth = 4 * d; strokeCap = Paint.Cap.ROUND }

    private fun label(s: String, color: Int, size: Float = 17f, bold: Boolean = false) = TextView(context).apply {
        text = s; setTextColor(color); textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding((14 * d).toInt(), (10 * d).toInt(), (14 * d).toInt(), (10 * d).toInt())
    }

    private val cancelB = label("Cancel", BLUE)
    private val saveB = label("Save", BLUE)
    private val title = label("New Gesture", Color.WHITE, 17f, true)
    private val hint = label("Tap or swipe to create a custom gesture.\n\nA sequence of gestures will be combined into one multiple-touch gesture.", GREY, 15f)
    private val playB = label("Play", BLUE, 15f)
    private val stopB = label("Stop", BLUE, 15f)

    init {
        setWillNotDraw(false)
        setBackgroundColor(Color.BLACK)
        val top = (34 * d).toInt()
        addView(cancelB, LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { topMargin = top; marginStart = (6 * d).toInt() })
        addView(title, LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = top })
        addView(saveB, LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { topMargin = top; marginEnd = (6 * d).toInt() })
        hint.gravity = Gravity.CENTER
        addView(hint, LayoutParams(-1, -2, Gravity.CENTER).apply { marginStart = (40 * d).toInt(); marginEnd = (40 * d).toInt() })
        addView(playB, LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { bottomMargin = (30 * d).toInt(); marginStart = (10 * d).toInt() })
        addView(stopB, LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { bottomMargin = (30 * d).toInt(); marginEnd = (10 * d).toInt() })
        saveB.alpha = 0.4f

        cancelB.setOnClickListener { if (!naming) onCancel() }
        saveB.setOnClickListener {
            if (naming || (done.isEmpty() && live.isEmpty())) return@setOnClickListener
            lockRecording(); askName()
        }
        playB.setOnClickListener {
            if (naming) return@setOnClickListener
            lockRecording()
            if (done.isNotEmpty()) { previewing = true; previewT0 = SystemClock.uptimeMillis(); postInvalidateOnAnimation() }
        }
        stopB.setOnClickListener {
            if (naming) return@setOnClickListener
            if (previewing) previewing = false else lockRecording()
            invalidate()
        }
    }

    private fun lockRecording() {
        val now = SystemClock.uptimeMillis()
        live.keys.toList().forEach { finish(it, now) }
        locked = true
    }

    private fun finish(id: Int, now: Long) {
        live.remove(id)?.let {
            it.add(Pt(it.last().x, it.last().y, now - t0))
            done.add(Stroke(it.toList()))
        }
        saveB.alpha = if (done.isEmpty()) 0.4f else 1f
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (locked || previewing || naming) return true
        getLocationOnScreen(loc)
        val now = e.eventTime
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (t0 == 0L) t0 = now
                val i = e.actionIndex
                live[e.getPointerId(i)] = mutableListOf(Pt(e.getX(i) + loc[0], e.getY(i) + loc[1], now - t0))
                hint.visibility = GONE
                saveB.alpha = 1f
                postInvalidateOnAnimation()
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) {
                val l = live[e.getPointerId(i)] ?: continue
                val x = e.getX(i) + loc[0]; val y = e.getY(i) + loc[1]
                val last = l.last()
                if (Math.hypot((x - last.x).toDouble(), (y - last.y).toDouble()) >= 2.0) l.add(Pt(x, y, now - t0))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> finish(e.getPointerId(e.actionIndex), now)
            MotionEvent.ACTION_CANCEL -> live.keys.toList().forEach { finish(it, now) }
        }
        invalidate()
        return true
    }

    private fun pathOf(p: List<Pt>, ox: Float, oy: Float): Path {
        val path = Path()
        path.moveTo(p[0].x - ox, p[0].y - oy)
        if (p.size == 1) path.lineTo(p[0].x - ox + 0.1f, p[0].y - oy)
        for (i in 1 until p.size) path.lineTo(p[i].x - ox, p[i].y - oy)
        if (p.size > 1 && p.size < 3) path.lineTo(p.last().x - ox + 0.1f, p.last().y - oy)
        return path
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat(); val oy = loc[1].toFloat()
        var frac = 0f
        if (previewing) {
            val t = SystemClock.uptimeMillis() - previewT0
            val dur = (done.maxOfOrNull { it.end } ?: 1L).coerceAtLeast(1L)
            drawTouches(c, done, t, ox, oy, 30 * d, ring, fill)
            frac = (t.toFloat() / dur).coerceIn(0f, 1f)
            if (t > dur + 300) previewing = false
        } else {
            done.forEach { c.drawPath(pathOf(it.pts, ox, oy), trail) }
            live.values.forEach { if (it.isNotEmpty()) c.drawPath(pathOf(it, ox, oy), trail) }
            if (t0 != 0L && !locked) {
                val el = SystemClock.uptimeMillis() - t0
                frac = (el / 60000f).coerceIn(0f, 1f)
                if (el > 59000) lockRecording()
            } else if (done.isNotEmpty()) frac = ((done.maxOf { it.end }) / 60000f).coerceIn(0f, 1f)
        }
        val y = height - 44 * d
        val x1 = 90 * d; val x2 = width - 90 * d
        c.drawLine(x1, y, x2, y, track)
        c.drawLine(x1, y, x1 + (x2 - x1) * frac, y, prog)
        if (previewing || (t0 != 0L && !locked)) postInvalidateOnAnimation()
    }

    private fun askName() {
        naming = true
        val et = EditText(context).apply {
            hint = "Gesture name"; setText(defaultName); setSelectAllOnFocus(true)
            setTextColor(Color.WHITE); setHintTextColor(GREY); isSingleLine = true
        }
        val p = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(0xFF2C2C2E.toInt()); cornerRadius = 16 * d }
            setPadding((18 * d).toInt(), (18 * d).toInt(), (18 * d).toInt(), (8 * d).toInt())
            isClickable = true
        }
        p.addView(TextView(context).apply { text = "New Gesture"; setTextColor(Color.WHITE); textSize = 17f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        p.addView(et, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (12 * d).toInt() })
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        val c = label("Cancel", BLUE)
        val s = label("Save", BLUE, 17f, true)
        row.addView(c); row.addView(s)
        p.addView(row)
        c.setOnClickListener { closePanel() }
        s.setOnClickListener {
            val name = et.text.toString().trim().ifEmpty { defaultName }
            hideKeyboard(et)
            onSave(name, done.toList())
        }
        addView(p, LayoutParams((290 * d).toInt(), -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = (110 * d).toInt() })
        panel = p
        et.requestFocus()
        postDelayed({
            (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
        }, 250)
    }

    private fun hideKeyboard(v: android.view.View) {
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
    }

    private fun closePanel() {
        panel?.let { hideKeyboard(it); removeView(it) }
        panel = null; naming = false
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BACK && e.action == KeyEvent.ACTION_UP) {
            if (naming) closePanel() else onCancel()
            return true
        }
        return super.dispatchKeyEvent(e)
    }
}
