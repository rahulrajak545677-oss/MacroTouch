package com.macrotouch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.*
import android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
import android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
import android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
import android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
import android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
import android.view.WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
import android.view.accessibility.AccessibilityEvent
import android.widget.*

class TouchService : AccessibilityService() {

    companion object { @Volatile var inst: TouchService? = null }

    private class Item(val sym: String, val label: String, val act: () -> Unit)

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var button: View? = null
    private var bp: WindowManager.LayoutParams? = null
    private var menu: FrameLayout? = null
    private var recorder: RecorderView? = null
    private var viz: VizView? = null
    private var picker: View? = null
    @Volatile private var playing = false
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val dm get() = resources.displayMetrics
    private fun dp(v: Int) = (v * dm.density).toInt()

    override fun onServiceConnected() {
        inst = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Store.getBool(this, "enabled", false)) showButton()
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stopPlayback() }
    override fun onUnbind(intent: Intent?): Boolean {
        stopPlayback(); closeMenu(); removeRecorder(); hideButton(); inst = null
        return super.onUnbind(intent)
    }

    private fun lp(w: Int, hh: Int, extra: Int = 0, focusable: Boolean = false): WindowManager.LayoutParams {
        val f = FLAG_LAYOUT_IN_SCREEN or FLAG_LAYOUT_NO_LIMITS or extra or (if (focusable) 0 else FLAG_NOT_FOCUSABLE)
        val p = WindowManager.LayoutParams(w, hh, TYPE_ACCESSIBILITY_OVERLAY, f, PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        return p
    }
    private fun realSize(): Point {
        val m = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
        return Point(m.widthPixels, m.heightPixels)
    }
    private fun safeRemove(v: View?) { try { if (v != null) wm.removeView(v) } catch (_: Exception) {} }

    // ───────────── floating button ─────────────
    private class BtnView(c: android.content.Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            p.color = 0xE63A3A3C.toInt(); cv.drawRoundRect(0f, 0f, w, w, w * 0.28f, w * 0.28f, p)
            p.color = 0x99FFFFFF.toInt(); cv.drawCircle(w / 2, w / 2, w * 0.34f, p)
            p.color = 0xFFFFFFFF.toInt(); cv.drawCircle(w / 2, w / 2, w * 0.26f, p)
        }
    }

    private val dimR = Runnable { button?.alpha = Store.getInt(this, "opacity", 37) / 100f }
    private fun wake() { h.removeCallbacks(dimR); button?.alpha = 1f }
    private fun dim() { h.removeCallbacks(dimR); h.postDelayed(dimR, 3000) }

    fun showButton() {
        if (button != null) return
        val size = dp(58)
        val v = BtnView(this)
        val p = lp(size, size).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Store.getInt(this@TouchService, "bx", dm.widthPixels - size - dp(6))
            y = Store.getInt(this@TouchService, "by", dm.heightPixels / 2)
        }
        var dx = 0f; var dy = 0f; var ox = 0; var oy = 0; var drag = false
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { runAction("a_single"); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean { runAction("a_double"); return true }
            override fun onLongPress(e: MotionEvent) { if (!drag) runAction("a_long") }
        })
        v.setOnTouchListener { _, e ->
            wake()
            gd.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ox = p.x; oy = p.y; drag = false }
                MotionEvent.ACTION_MOVE -> {
                    if (!drag && Math.hypot((e.rawX - dx).toDouble(), (e.rawY - dy).toDouble()) > dp(8)) drag = true
                    if (drag) {
                        p.x = (ox + e.rawX - dx).toInt(); p.y = (oy + e.rawY - dy).toInt()
                        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (drag) {
                        val sw = realSize().x
                        p.x = if (p.x + size / 2 < sw / 2) dp(6) else sw - size - dp(6)
                        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
                        Store.putInt(this, "bx", p.x); Store.putInt(this, "by", p.y)
                    }
                    dim()
                }
            }
            true
        }
        wm.addView(v, p); button = v; bp = p
        dim()
    }

    fun hideButton() { h.removeCallbacks(dimR); safeRemove(button); button = null }

    private fun runAction(key: String) {
        if (playing) { stopPlayback(); toast("Stopped"); return }
        val def = if (key == "a_single") "menu" else "none"
        val a = Store.getStr(this, key, def)
        when {
            a == "menu" -> showMenu()
            a.startsWith("m:") -> Store.load(this).firstOrNull { it.name == a.substring(2) }?.let { play(it) }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ───────────── menu ─────────────
    private fun g(action: Int) { closeMenu(); h.postDelayed({ performGlobalAction(action) }, 180) }

    private fun showMenu(page: String = "top") {
        closeMenu()
        val items: List<Item?> = when (page) {
            "custom" -> listOf<Item?>(Item("←", "Back") { showMenu() }) +
                Store.load(this).map { m -> Item("★", m.name) { closeMenu(); play(m) } } +
                Item("+", "New") { startRecorder() }
            "gestures" -> listOf<Item?>(
                Item("←", "Back") { showMenu() },
                Item("◉", "Long Press") { pick("Long Press") },
                Item("◎", "Double Tap") { pick("Double Tap") },
                Item("⤡", "Pinch In") { pick("Pinch In") },
                Item("⤢", "Pinch Out") { pick("Pinch Out") },
                Item("↑", "Swipe Up") { closeMenu(); h.postDelayed({ doGesture("Swipe Up", 0f, 0f) }, 180) },
                Item("↓", "Swipe Down") { closeMenu(); h.postDelayed({ doGesture("Swipe Down", 0f, 0f) }, 180) }
            )
            "device" -> {
                val l = mutableListOf<Item?>(
                    Item("←", "Back") { showMenu() },
                    Item("◁", "Back Button") { g(GLOBAL_ACTION_BACK) },
                    Item("▭", "App Switcher") { g(GLOBAL_ACTION_RECENTS) },
                    Item("⏻", "Power Menu") { g(GLOBAL_ACTION_POWER_DIALOG) }
                )
                if (Build.VERSION.SDK_INT >= 28) {
                    l.add(Item("🔒", "Lock Screen") { g(GLOBAL_ACTION_LOCK_SCREEN) })
                    l.add(Item("📷", "Screenshot") { g(GLOBAL_ACTION_TAKE_SCREENSHOT) })
                }
                l
            }
            else -> listOf(
                null, Item("🔔", "Notification Center") { g(GLOBAL_ACTION_NOTIFICATIONS) }, null,
                Item("★", "Custom") { showMenu("custom") }, null, Item("▯", "Device") { showMenu("device") },
                Item("◎", "Gestures") { showMenu("gestures") }, Item("⌂", "Home") { g(GLOBAL_ACTION_HOME) },
                Item("⚙", "Control Center") { g(GLOBAL_ACTION_QUICK_SETTINGS) }
            )
        }
        val root = FrameLayout(this).apply { setBackgroundColor(0x33000000); setOnClickListener { closeMenu() } }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            isClickable = true
        }
        items.chunked(3).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until 3) row.addView(tile(rowItems.getOrNull(i)), LinearLayout.LayoutParams(dp(100), dp(92)))
            col.addView(row)
        }
        val panel = ScrollView(this).apply {
            background = GradientDrawable().apply { setColor(0xEE2C2C2E.toInt()); cornerRadius = dp(26).toFloat() }
            addView(col)
        }
        val tall = items.size > 9
        root.addView(panel, FrameLayout.LayoutParams(dp(330), if (tall) (dm.heightPixels * 0.7).toInt() else WRAP, Gravity.CENTER))
        wm.addView(root, lp(MATCH, MATCH))
        menu = root
    }

    private fun tile(item: Item?): View {
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        if (item == null) return t
        t.addView(TextView(this).apply { text = item.sym; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        t.addView(TextView(this).apply {
            text = item.label; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            maxLines = 2; setPadding(dp(4), dp(4), dp(4), 0)
        })
        t.setOnClickListener { item.act() }
        return t
    }

    private fun closeMenu() { safeRemove(menu); menu = null; safeRemove(picker); picker = null }

    // ───────────── built-in gestures ─────────────
    private fun pick(kind: String) {
        closeMenu()
        val v = FrameLayout(this).apply { setBackgroundColor(0x44000000) }
        v.addView(TextView(this).apply {
            text = "Tap where you want to use:\n$kind"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER))
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                val x = e.rawX; val y = e.rawY
                safeRemove(picker); picker = null
                h.postDelayed({ doGesture(kind, x, y) }, 220)
            }
            true
        }
        wm.addView(v, lp(MATCH, MATCH)); picker = v
    }

    private fun st(x1: Float, y1: Float, x2: Float, y2: Float, start: Long, dur: Long): GestureDescription.StrokeDescription {
        val p = Path(); p.moveTo(x1, y1); if (x1 != x2 || y1 != y2) p.lineTo(x2, y2)
        return GestureDescription.StrokeDescription(p, start, dur)
    }

    private fun doGesture(kind: String, x: Float, y: Float) {
        val sz = realSize(); val b = GestureDescription.Builder(); val k = dp(130).toFloat(); val n = dp(20).toFloat()
        when (kind) {
            "Long Press" -> b.addStroke(st(x, y, x, y, 0L, 1000L))
            "Double Tap" -> { b.addStroke(st(x, y, x, y, 0L, 40L)); b.addStroke(st(x, y, x, y, 130L, 40L)) }
            "Pinch In" -> { b.addStroke(st(x - k, y, x - n, y, 0L, 400L)); b.addStroke(st(x + k, y, x + n, y, 0L, 400L)) }
            "Pinch Out" -> { b.addStroke(st(x - n, y, x - k, y, 0L, 400L)); b.addStroke(st(x + n, y, x + k, y, 0L, 400L)) }
            "Swipe Up" -> b.addStroke(st(sz.x / 2f, sz.y * 0.72f, sz.x / 2f, sz.y * 0.28f, 0L, 350L))
            "Swipe Down" -> b.addStroke(st(sz.x / 2f, sz.y * 0.28f, sz.x / 2f, sz.y * 0.72f, 0L, 350L))
        }
        try { dispatchGesture(b.build(), null, null) } catch (_: Exception) {}
    }

    // ───────────── recorder ─────────────
    fun startRecorder() {
        stopPlayback(); closeMenu(); removeRecorder()
        val list = Store.load(this)
        var n = list.size + 1
        while (list.any { it.name == "Macro$n" }) n++
        val r = RecorderView(this, "Macro$n", { removeRecorder() }) { name, strokes ->
            val l = Store.load(this)
            var nm = name; var k = 2
            while (l.any { it.name == nm }) { nm = "$name $k"; k++ }
            l.add(Macro(nm, strokes)); Store.save(this, l)
            removeRecorder(); toast("Saved “$nm”")
        }
        wm.addView(r, lp(MATCH, MATCH, 0, true).also { it.softInputMode = SOFT_INPUT_ADJUST_PAN })
        recorder = r
    }
    private fun removeRecorder() { safeRemove(recorder); recorder = null }

    // ───────────── playback ─────────────
    private class VizView(c: android.content.Context, val m: Macro) : View(c) {
        var t0 = SystemClock.uptimeMillis()
        private val d = c.resources.displayMetrics.density
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2D3A.toInt(); style = Paint.Style.STROKE; strokeWidth = 3 * d }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2D3A.toInt() }
        private val loc = IntArray(2)
        override fun onDraw(c: Canvas) {
            getLocationOnScreen(loc)
            drawTouches(c, m.strokes, SystemClock.uptimeMillis() - t0, loc[0].toFloat(), loc[1].toFloat(), 22 * d, ring, fill)
            postInvalidateOnAnimation()
        }
    }

    private fun pathOf(s: Stroke): Path {
        val sz = realSize(); val mw = sz.x - 1f; val mh = sz.y - 1f
        val f = s.pts.first()
        val p = Path(); p.moveTo(f.x.coerceIn(0f, mw), f.y.coerceIn(0f, mh))
        var moved = false
        for (i in 1 until s.pts.size) {
            val q = s.pts[i]
            if (Math.hypot((q.x - f.x).toDouble(), (q.y - f.y).toDouble()) > 2.0) moved = true
            p.lineTo(q.x.coerceIn(0f, mw), q.y.coerceIn(0f, mh))
        }
        return if (moved) p else Path().apply { moveTo(f.x.coerceIn(0f, mw), f.y.coerceIn(0f, mh)) }
    }

    private fun clusters(m: Macro): List<List<Stroke>> {
        val out = mutableListOf<MutableList<Stroke>>()
        var curEnd = -1L
        for (s in m.strokes.sortedBy { it.start }) {
            val cur = out.lastOrNull()
            if (cur != null && s.start < curEnd + 5 && cur.size < 10) { cur.add(s); curEnd = maxOf(curEnd, s.end) }
            else { out.add(mutableListOf(s)); curEnd = s.end }
        }
        return out
    }

    private fun fire(c: List<Stroke>) {
        val base = c.first().start
        val b = GestureDescription.Builder()
        c.forEach { s ->
            val dur = (s.end - s.start).coerceIn(30L, 59000L)
            b.addStroke(GestureDescription.StrokeDescription(pathOf(s), s.start - base, dur))
        }
        try { dispatchGesture(b.build(), null, null) } catch (_: Exception) {}
    }

    fun play(m: Macro) {
        stopPlayback()
        if (m.strokes.isEmpty()) return
        playing = true
        viz = VizView(this, m).also { wm.addView(it, lp(MATCH, MATCH, FLAG_NOT_TOUCHABLE)) }
        toast("Playing “${m.name}” — tap the floating button to stop")
        runLoop(m, Store.getInt(this, "loops", 1), 1, Store.getInt(this, "gap", 0).toLong())
    }

    private fun runLoop(m: Macro, loops: Int, n: Int, gap: Long) {
        if (!playing) return
        viz?.t0 = SystemClock.uptimeMillis()
        clusters(m).forEach { c -> h.postDelayed({ if (playing) fire(c) }, c.first().start) }
        h.postDelayed({
            if (!playing) return@postDelayed
            if (loops == 0 || n < loops) runLoop(m, loops, n + 1, gap) else stopPlayback()
        }, m.duration + gap + 80)
    }

    fun stopPlayback() {
        playing = false
        h.removeCallbacksAndMessages(null)
        safeRemove(viz); viz = null
        if (button != null) dim()
    }
}
